package com.amdocs.DockerDemo;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MyController {

	@GetMapping("/get")
	public String print() {
		return "Welcome to Spring boot World";
	}
	
	@GetMapping("/in")
	public String print2() {
		return "We are going to dockerize springboot application";
	}


}
