package com.amdocs.FinalProject;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.JavascriptExecutor;
public class RunGFG {
	public static void main(String args[]) {
		try {
			EdgeDriver ed= new EdgeDriver();
			ed.manage().window().maximize();
			Actions actions = new Actions(ed);
			
			//Load GFG web page
			ed.get("https://www.geeksforgeeks.org/");
			Thread.sleep(3000); //Wait for Page to load
			
			
			ed.findElement(By.xpath("/html/body/nav/div/div[1]/ul[2]/li[2]/div/button")).click();
			Thread.sleep(2000);
			ed.findElement(By.xpath("//*[@id=\"userProfileId\"]/a")).click();
			Thread.sleep(3000);  //Wait for Sign up pop up to load
			
			
			//insert login id and password
			ed.findElement(By.xpath("//*[@id=\"luser\"]")).sendKeys("1132210047@mitwpu.edu.in");
			ed.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Archery@360");
			ed.findElement(By.xpath("//*[@id=\"Login\"]/button")).click();
			Thread.sleep(3000);
			
			//Using action class to get drop down by hovering over Courses section
			actions.moveToElement(ed.findElement(By.xpath("/html/body/nav/div/div[1]/ul[1]/li[1]"))).perform();
			
			//click on all courses
			ed.findElement(By.xpath("/html/body/nav/div/div[1]/ul[1]/li[1]/ul/li[5]/a")).click();
			Thread.sleep(3000);
			
			//click on the dsa banner
			WebElement targetElement = ed.findElement(By.xpath("//*[@id=\"__next\"]/div/div[4]/div[2]/div/div[6]/div[2]")); // Replace with your target element locator
			// Scroll to the target element using JavaScript
	        ((JavascriptExecutor) ed).executeScript("arguments[0].scrollIntoView(true);", targetElement);
	        //targetElement.click();
			String originalTabHandle = ed.getWindowHandle();
			Thread.sleep(2000);
			ed.findElement(By.xpath("//*[@id=\"__next\"]/div/div[4]/div[2]/div/div[6]/div[2]/div/a[1]")).click();
			//Thread.sleep(3000);
			
			Set<String> allTabHandles = ed.getWindowHandles();
	        for (String tabHandle : allTabHandles) {
	            if (!tabHandle.equals(originalTabHandle)) {
	                ed.switchTo().window(tabHandle);
	                break;
	            }
	        }
	        System.out.println(allTabHandles);
	        Thread.sleep(3000);
			
	        WebElement cookiebtn=ed.findElement(By.xpath("//*[@id=\"rcc-confirm-button\"]"));
	        cookiebtn.click();
	        Thread.sleep(1000);
	        WebElement signupbtn =ed.findElement(By.xpath("//*[@id=\"__next\"]/div/div[3]/div[1]/section[1]/div[2]/div/div[2]/div[4]/div[1]/div/div/button"));
	        signupbtn.click();
	        
			//ed.findElement(By.xpath("//*[@id=\"__next\"]/div/div[4]/div[1]/section[1]/div[2]/div/div[2]/div[4]/div[1]/div/button")).click();
	
	
		}
		catch(Exception e){
			System.out.println(e);
		}
	
	}

}
