package com.amdocs.FinalProject;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

public class GFGtest {
	WebDriver dr= new EdgeDriver();
	SoftAssert sa=new SoftAssert();
	@Test
	public void titletestpass() {
		
		
		dr.get("https://www.geeksforgeeks.org/");
		String expTitile = "GeeksforGeeks | A computer science portal for geeks";
		
		String actTitle = dr.getTitle();
		//System.out.println(actTitle);
		System.out.println(dr.getTitle());
		sa.assertEquals(actTitle, expTitile);
		
		String btnText=dr.findElement(By.xpath("//*[@id=\"RA-root\"]/div/div[1]/div[1]/div[2]/span/span/span[2]/button")).getText();
		System.out.println(btnText);
		String expText="Search";
		sa.assertEquals(btnText, expText);
		sa.assertAll();
		
	}
	
//	@Test
//	public void titletestfail() {
//		
//		dr.get("https://www.geeksforgeeks.org/");
//		String expTitile = "GeeksforGeeks";
//		
//		String actTitle = dr.getTitle();
//		//System.out.println(actTitle);
//		System.out.println(dr.getTitle());
//		sa.assertEquals(actTitle, expTitile);
//		
//		
//	}

}
